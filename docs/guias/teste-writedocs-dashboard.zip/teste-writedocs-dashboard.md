# Teste do WriteDocs dashboard

Teste de 02 a 04/11/2026 no dashboard novo, usando o Mintlify como referência. Projetos testados: "Let's break this", criado sem repositório, e "WriteDocs Teste Github", conectado a um repositório no formato do Mintlify.

## Resumo

- **57 itens**: 4 de severidade alta, 14 média, 34 baixa e 5 sugestões.
- **Maior distância do Mintlify:** o editor só tem modo código e não há prévia antes de publicar (item 01).
- **Maior falha:** o "stable" do gerador mudou antes de a imagem do build estar pronta. O publish levou 7 min 33 s, com três tentativas falhas escondidas atrás de um status "Building" (itens 02 e 09).
- **Migração do Mintlify:** um repositório no formato do Mintlify conecta, mas não vira site, porque o docs.json é ignorado e não há como criar o writedocs.json pelo dashboard (itens 03 e 18).
- **Aviso antes da hora:** logo depois do clique em Publish, o aviso diz "Published", antes do build e, com GitHub, antes do commit (item 04).
- **Melhor resultado:** uma página escrita para o Mintlify, com 13 tipos de componente e tabela HTML com células mescladas, publicou sem nenhuma alteração.

**Paridade:** o Mintlify faz isso, e o WriteDocs não faz ou faz diferente. **Próprio:** não há equivalente no Mintlify para comparar.

---

## Severidade alta (4)

### 01. O editor só tem modo código, e não há prévia antes de publicar

*Content, editor · Paridade*

**O que acontece:** Toda página abre como texto cru, com o frontmatter à mostra. Não há modo visual nem prévia ao lado, e não achamos jeito de ver a página renderizada antes de publicar. Para conferir a página de componentes, foi preciso publicar no site. O web editor do Mintlify tem modo visual, modo código e live preview. Para um produto que quer ser quase um clone, é a maior distância, porque o modo visual é o que deixa quem não é dev escrever.

**Esperado:** Modo visual com alternância para código, ou no mínimo prévia renderizada ao lado. Prévia antes de publicar.

![Print do item 01](relatorio/img/01-1.webp)

### 02. Três tentativas falharam e o status continuou "Building"

*Deployments · Paridade*

**O que acontece:** O publish de 02:53 PM falhou três vezes e só passou na quarta, 7 min 33 s depois do clique (o anterior levou 1 min 39 s). Durante todo esse tempo o status dizia "Building" e o topo dizia "Publishing". A falha só aparecia nas abas do log. A causa, no log da tentativa 3, é generator_version_mismatch: o "stable" virou 0.14.0 antes de a imagem do container ter essa versão. O build espera 2 minutos entre tentativas, até 18 vezes. O próprio log diz que o conteúdo não tinha erro.

**Esperado:** Só mudar o "stable" depois que a imagem estiver distribuída. Enquanto espera, status "Waiting for the new generator version" e tentativas como "waiting", não "failed". Se todas falharem, "Failed" com o motivo, como faz o Mintlify.

![Print do item 02](relatorio/img/02-1.webp)

### 03. Um repositório no formato do Mintlify não vira site

*Source and sync · Paridade*

**O que acontece:** O repositório de teste tem o formato do Mintlify: docs.json e páginas MDX. O sync trouxe as páginas, mas ignorou o docs.json. Sem writedocs.json, a aba Navigation e a tela Site ficam vazias ("This project has no writedocs.json yet"), e o Publish fica desativado. Não existe conversão do docs.json, nem botão para criar um writedocs.json pelo dashboard. Para um produto que quer ser quase um clone do Mintlify, o caminho de quem vem do Mintlify não funciona.

**Esperado:** Ler o docs.json do Mintlify, ou oferecer converter: "This repository uses Mintlify's docs.json. Create writedocs.json from it?". No mínimo, um botão para criar um writedocs.json inicial com as páginas encontradas.

![Print do item 03](relatorio/img/03-1.webp)

![Print do item 03](relatorio/img/03-2.webp)

### 04. O aviso diz "Published" enquanto ainda está publicando

*Publish · Próprio*

**O que acontece:** Ao publicar, aparece "Published. The site updates in a moment." enquanto o topo diz "Publishing shortly". No fim vem "The site was published.". Os dois avisos dizem "publicado". Em projeto com GitHub, o aviso é "Published. The change goes to GitHub in a few seconds, and the site updates right after.": a segunda frase explica a ordem, mas o "Published" continua chegando antes do commit e do site.

**Esperado:** Primeiro aviso dizendo "Publishing..." e apontando para o status no topo.

![Print do item 04](relatorio/img/04-1.webp)

![Print do item 04](relatorio/img/04-2.webp)

---

## Severidade média (14)

### 05. O conteúdo inicial sai em português num projeto em inglês

*Site gerado · Paridade*

**O que acontece:** A página inicial e o grupo da navegação vêm em português ("Documentação", "Esta é a primeira página..."). O dashboard e o nome do projeto estão em inglês, e a criação não pergunta idioma.

**Esperado:** Idioma vindo de uma escolha na criação, ou inglês como no starter do Mintlify.

![Print do item 05](relatorio/img/05-1.webp)

### 06. A árvore de navegação mostra o nome do arquivo, não o título

*Content, Navigation · Paridade*

**O que acontece:** O index.mdx tem title: "Let's break this" e o site usa esse título, mas a árvore mostra "index". O contador "0 not found" não diz o que conta, e "open in Site" está em minúscula.

**Esperado:** Título da página na árvore, como no editor do Mintlify. Algo como "0 missing pages".

![Print do item 06](relatorio/img/06-1.webp)

![Print do item 06](relatorio/img/06-2.webp)

### 07. "See the build" abre o build anterior enquanto o novo está na fila

*Status no topo · Próprio*

**O que acontece:** Com o status em "Publishing shortly", o build novo ainda não existe. O link abriu o build de 02:45 PM, que aparece como Published e Live. Quem clica acha que está vendo o build novo.

**Esperado:** Enquanto o build não existe, levar para a lista de Deployments ou mostrar "na fila".

![Print do item 07](relatorio/img/07-1.webp)

### 08. O log mistura idiomas e expõe a infraestrutura

*Deployments, log · Próprio*

**O que acontece:** Linhas em português ("versão do gerador", "núcleos que o processo vê") ao lado de linhas em inglês ("Built 3 pages"). O log mostra CPU, cgroup, "não lido (ENOENT)", threads, compressão, envio para o R2, MD5 e ids internos. Para o cliente, isso parece erro.

**Esperado:** Log em um idioma só. Diagnóstico interno escondido, ou atrás de "mostrar detalhes".

![Print do item 08](relatorio/img/08-1.webp)

### 09. "Follow stable" trocou a versão do gerador sem aviso

*Settings, General · Próprio*

**O que acontece:** No meio do teste, o projeto passou do gerador 0.13.5 para o 0.14.0 sozinho. Nada no dashboard avisou. Foi essa troca que causou o atraso do item 02.

**Esperado:** Avisar no dashboard quando o "stable" muda, com link para as notas da versão.

![Print do item 09](relatorio/img/09-1.webp)

### 10. Logo depois do Publish, o menu diz "You saved a change"

*Status no topo · Próprio*

**O que acontece:** No vídeo, a pessoa salva (o topo do arquivo diz "not published"), clica em Publish e confirma. O status vira "Publishing shortly", e o menu diz "You saved a change. The build starts in a few seconds.". Em todo o resto da interface, "saved" quer dizer o que ainda não foi publicado. O status passa depois por "Queued" ("The build is queued and starts soon."), "Publishing" e "Live" ("Published now."), cerca de 70 segundos depois do clique.

**Esperado:** Descrever a ação que a pessoa fez: "You published a change. The build starts in a few seconds." E avaliar se "Publishing shortly" e "Queued" precisam ser dois estados diferentes.

![Print do item 10](relatorio/img/10-1.webp)

### 11. O modal de nova aba diz que a mudança vai ao site quando você salva

*Content, Navigation · Próprio*

**O que acontece:** "Add: Tab" diz "The change shows in the navigation right away, and goes to the site when you save.". No vídeo, salvar a navegação não levou nada ao site: apareceu "Saved, not published yet", e a aba nova só apareceu no site depois do Publish.

**Esperado:** "The change shows in the navigation right away. It goes to the site when you publish."

![Print do item 11](relatorio/img/11-1.webp)

### 12. Não há como renomear um arquivo pelo dashboard

*Content · Paridade*

**O que acontece:** Na aba Files, o arquivo não tem menu: o clique com o botão direito abre o menu do navegador. Na aba Navigation, o menu de três pontos tem "Change the page...", "Move up", "Move down", "Move to..." e "Remove", mas nenhum "Rename". Como o endereço da página sai do nome do arquivo, também não dá para mudar a URL de uma página. Não deu para testar o redirect do endereço antigo.

**Esperado:** Renomear o arquivo pelo dashboard, mostrando o endereço novo e dizendo se o antigo redireciona. Confirmar como o editor do Mintlify trata a renomeação.

![Print do item 12](relatorio/img/12-1.webp)

### 13. O item Components abre o guia de estilo interno do dashboard

*Components (rodapé da sidebar) · Próprio*

**O que acontece:** O item "Components", no rodapé da sidebar, abre /design-system: uma página em português, com o título "Componentes", que mostra as cores, a tipografia e os botões do próprio dashboard ("Componente nenhum usa cor crua: tudo sai de src/styles/global.css"). É material da equipe que desenvolve o produto. Quem usa o WriteDocs pode achar que são os componentes disponíveis para a documentação, como os do Mintlify.

**Esperado:** Tirar do menu de quem usa o produto, ou mostrar só para a equipe interna. Se a ideia é listar os componentes da documentação (Note, Tabs, Steps), a página precisa ser outra.

![Print do item 13](relatorio/img/13-1.webp)

### 14. A validação ignora chaves que não conhece

*Site, JSON · Próprio*

**O que acontece:** Com "openapi": "teste.yaml" no writedocs.json, a validação disse "No errors." e o publish passou, embora o arquivo não exista. No segundo teste, trocar "name" por "nmae" gerou erro só porque o "name" sumiu ("name" is required, but writedocs.json does not set it); a chave "nmae" em si não foi apontada. Ou seja, qualquer chave escrita errada que não seja obrigatória passa em silêncio, e a configuração simplesmente não vale.

**Esperado:** Avisar de chave desconhecida, com sugestão: "Unknown key "nmae". Did you mean "name"?". E, se "openapi" for uma chave válida, avisar que o arquivo não existe.

![Print do item 14](relatorio/img/14-1.webp)

![Print do item 14](relatorio/img/14-2.webp)

### 15. Depois do Discard, os erros continuam na tela

*Site, JSON · Próprio*

**O que acontece:** Depois de clicar em Discard, o JSON voltou ao normal, com "name": "Let's break this" na linha 2. Mesmo assim, a tela continua mostrando "1 error: name is required, but writedocs.json does not set it", o bloco "writedocs.json has errors" e o ponto vermelho em General. O erro descreve uma versão que já não existe. Ao recarregar a página (F5), os erros somem: o problema é só de exibição, a tela não valida de novo depois do Discard.

**Esperado:** Validar de novo depois do Discard e limpar os erros e o ponto vermelho.

![Print do item 15](relatorio/img/15-1.webp)

### 16. Excluir projeto ainda não funciona, mas o diálogo promete que sim

*Danger zone · Paridade*

**O que acontece:** O diálogo "Delete "WriteDocs Teste Github"?" diz que o conteúdo será apagado para sempre, pede para digitar o nome e oferece "Delete forever". Depois de tudo isso, aparece um aviso que some sozinho: "This doesn't work with real data yet: the platform doesn't have this part yet.". O projeto continua lá. A pessoa só descobre que a função não existe no último passo, e o aviso fala de "real data" e "platform", termos internos.

**Esperado:** Enquanto a exclusão não existir, desativar o botão Delete project com uma explicação ao lado ("Deleting projects isn't available yet."). Se a falha acontecer mesmo assim, mostrar no diálogo, que continua aberto, e não num aviso que some.

![Print do item 16](relatorio/img/16-1.webp)

![Print do item 16](relatorio/img/16-2.webp)

### 17. O pré-requisito do GitHub só aparece depois do clique, e o caminho não volta

*Source and sync · Próprio*

**O que acontece:** Em Source and sync, o botão "Install the GitHub App" parece ser o único passo. Só depois do clique aparece o erro "To install, your WriteDocs account needs to be linked to a GitHub account... Connect GitHub in sign-in methods". O link leva para a página da conta. Depois de autorizar no GitHub, a pessoa volta para a página da conta (account?notice=identity_linked), e não para o projeto. Tem que achar o caminho de volta para Source and sync sozinha.

**Esperado:** Dizer o passo antes do clique, por exemplo com dois passos numerados: "1. Link your GitHub account. 2. Install the GitHub App." Depois de vincular a conta, voltar direto para Source and sync.

![Print do item 17](relatorio/img/17-1.webp)

![Print do item 17](relatorio/img/17-2.webp)

### 18. A saída sugerida não serve para quem já conectou o repositório

*Content e Site · Próprio*

**O que acontece:** A mensagem diz "Connect a repository that has one, or create the project from the starter.". O repositório já está conectado, então a primeira saída não se aplica. A segunda obriga a criar outro projeto. O botão Publish fica desativado sem explicar por quê, e na tela Site ele nem aparece.

**Esperado:** Uma saída dentro do projeto: "Add a writedocs.json to the repository root, or create one here.", com um botão. E, no Publish desativado, dizer o motivo ("Publishing needs a writedocs.json").

![Print do item 18](relatorio/img/18-1.webp)

---

## Severidade baixa (34)

### 19. O endereço mostrado na criação não é o endereço real

*Criação de projeto · Próprio*

**O que acontece:** O texto de apoio do slug diz testing-slug-i-can-edit.writedocs.io, mas o site sai em <slug>-dev.writedocs.io.

**Esperado:** Mostrar o endereço que vai existir neste ambiente.

![Print do item 19](relatorio/img/19-1.webp)

![Print do item 19](relatorio/img/19-2.webp)

### 20. A página inicial manda conectar o GitHub num projeto sem repositório

*Site gerado · Próprio*

**O que acontece:** O projeto foi criado com "Start without a repository". Mesmo assim, a página inicial diz que, para trazer o conteúdo, é preciso conectar o GitHub. O editor nem é citado.

**Esperado:** Citar o editor primeiro e o GitHub como opção, como faz o card da criação.

![Print do item 20](relatorio/img/20-1.webp)

### 21. Apóstrofo curvo no corpo e reto no título

*Site gerado · Próprio*

**O que acontece:** No arquivo o apóstrofo é reto nos dois lugares. No site, o corpo sai "Let’s" e o título sai "Let's". O gerador converte as aspas no corpo, mas não no título.

**Esperado:** A mesma regra no título e no corpo.

![Print do item 21](relatorio/img/21-1.webp)

### 22. O nome do projeto aparece três vezes na página inicial

*Site gerado · Paridade*

**O que acontece:** A página inicial usa o nome do projeto como título. O topo do site, o item da sidebar e o H1 dizem "Let's break this".

**Esperado:** Título genérico de página inicial, como o "Introduction" do starter do Mintlify.

![Print do item 22](relatorio/img/22-1.webp)

### 23. Dois itens "General" com papéis diferentes

*Navegação do dashboard · Próprio*

**O que acontece:** Settings > General é o projeto no dashboard e salva com um botão fixo. Site > General é o site publicado e mostra uma barra de salvar só quando algo muda. A tela de Site já explica a diferença, mas o nome repetido confunde, e cada uma salva de um jeito.

**Esperado:** Nomes distintos, como "Project" e "Site details". Um padrão só de salvar.

![Print do item 23](relatorio/img/23-1.webp)

### 24. "Conflicts" aparece num projeto sem repositório

*Navegação do dashboard · Próprio*

**O que acontece:** Sem repositório não há o que conflitar, mas o item fica na sidebar. Ao abrir, a tela diz "No conflicts. The content here and on GitHub match.", o que não é verdade: o projeto não tem GitHub.

**Esperado:** Esconder, ou um estado vazio que diga quando passa a valer: "Conflicts appear here when you connect a GitHub repository."

![Print do item 24](relatorio/img/24-1.webp)

![Print do item 24](relatorio/img/24-2.webp)

### 25. "Last build" repete a data de "Published"

*Overview · Paridade*

**O que acontece:** O campo mostra "Published, Nov 2, 02:11 PM", a mesma data dos campos ao lado. Os horários vêm em AM/PM e sem fuso.

**Esperado:** Mostrar o que só ele tem, como status e duração. Hora no formato do navegador.

![Print do item 25](relatorio/img/25-1.webp)

### 26. Traço azul solto embaixo dos dados

*Overview · Próprio*

**O que acontece:** Um traço curto aparece sozinho à esquerda. Parece indicador de aba ou barra de carregamento que sobrou.

**Esperado:** Sem elemento solto.

![Print do item 26](relatorio/img/26-1.webp)

### 27. O filtro só aplica depois de clicar em "Filter"

*Deployments · Paridade*

**O que acontece:** Escolher o status no menu não muda a lista. É preciso clicar no botão ao lado.

**Esperado:** Aplicar ao escolher.

![Print do item 27](relatorio/img/27-1.webp)

### 28. O cabeçalho muda de uma página para outra

*Cabeçalho · Próprio*

**O que acontece:** O botão Publish aparece em Content e Site, mas não em Overview, Deployments e Settings. A largura do conteúdo também muda, e os botões do topo pulam de lugar.

**Esperado:** Cabeçalho igual em todas as páginas do projeto.

![Print do item 28](relatorio/img/28-1.webp)

![Print do item 28](relatorio/img/28-2.webp)

### 29. "Expand on hover" não diz o que expande

*Content · Próprio*

**O que acontece:** Ao ligar a opção, o painel de arquivos ficou mais largo. O rótulo não explica isso.

**Esperado:** Rótulo que diga o efeito, ou tooltip.

![Print do item 29](relatorio/img/29-1.webp)

### 30. Não dá para saber se a cor está definida ou é o padrão

*Site, Appearance · Próprio*

**O que acontece:** O texto diz que campo vazio usa a cor padrão, "shown in the field". Mas o campo mostra o hex como se estivesse preenchido.

**Esperado:** Padrão como placeholder cinza, e valor definido como texto normal.

![Print do item 30](relatorio/img/30-1.webp)

### 31. A prévia usa navegação de exemplo, não a do projeto

*Site, Appearance · Paridade*

**O que acontece:** A prévia mostra Guides, Reference e Getting started. O projeto tem Documentação e as páginas reais. A prévia do Mintlify mostra o site real.

**Esperado:** Usar a navegação e o conteúdo reais, ou marcar a prévia como exemplo.

![Print do item 31](relatorio/img/31-1.webp)

### 32. Exemplo de domínio em português

*Domains · Próprio*

**O que acontece:** O campo mostra "docs.empresa.com" numa interface em inglês. O rótulo "Domain" está colado no campo.

**Esperado:** docs.example.com, e espaço entre rótulo e campo.

![Print do item 32](relatorio/img/32-1.webp)

### 33. O contador de arquivos não atualiza

*Content, Files · Próprio*

**O que acontece:** Depois de criar uma página, a lista mostra 3 arquivos, mas a aba continua "Files (2)".

**Esperado:** Contador atualizado na hora.

![Print do item 33](relatorio/img/33-1.webp)

### 34. Texto do modal repete a ideia

*Content, New page · Próprio*

**O que acontece:** "It stays saved without publishing until you publish" diz a mesma coisa duas vezes.

**Esperado:** "It's saved as a draft until you publish."

![Print do item 34](relatorio/img/34-1.webp)

### 35. A mensagem de commit padrão não é mostrada

*Review and publish · Próprio*

**O que acontece:** O texto diz que, se o campo ficar vazio, entra "the usual message", mas não diz qual é. A sugestão usa o nome do arquivo, não o título da página.

**Esperado:** Mensagem padrão como placeholder, e título da página na sugestão.

![Print do item 35](relatorio/img/35-1.webp)

### 36. O ponto de "não salvo" fica depois de desfazer a mudança

*Site, Appearance · Próprio*

**O que acontece:** Trocar o tema de código e voltar ao original, sem salvar, deixa o ponto na aba Code. O contador já ignora a volta e diz "1 unsaved change", que é a do Top bar.

**Esperado:** O ponto some quando o valor volta ao que estava salvo.

![Print do item 36](relatorio/img/36-1.webp)

### 37. O campo "Commit" do build fica vazio

*Deployments, build · Paridade*

**O que acontece:** O Review and publish sugeriu uma mensagem de commit, mas o campo Commit do build mostra só um traço, e a mensagem não aparece em lugar nenhum.

**Esperado:** Mensagem de commit no build e na lista de Deployments.

![Print do item 37](relatorio/img/37-1.webp)

### 38. Difícil copiar um log comprido

*Deployments, log · Próprio*

**O que acontece:** Selecionar pelo teclado não rola a caixa junto com a seleção. Ctrl+A seleciona a página inteira, mesmo com o cursor no log.

**Esperado:** Rolar com a seleção, Ctrl+A limitado ao log em foco, e botão de copiar ou baixar o log.

![Print do item 38](relatorio/img/38-1.webp)

### 39. O menu da direita não marca a seção clicada

*Site gerado, On this page · Paridade*

**O que acontece:** Clicar em "13. Update (changelog)" leva até a seção, mas o menu continua marcando "11. Image in a frame". As últimas seções não sobem até o topo, e o destaque segue a rolagem.

**Esperado:** Marcar o item clicado e, no fim da página, a última seção.

![Print do item 39](relatorio/img/39-1.webp)

### 40. <Expandable> abre já expandido

*Site gerado, componentes · Paridade*

**O que acontece:** Solto e dentro do ResponseField, o bloco aparece aberto ("Hide Expandable block", "Hide properties"). No Mintlify ele começa fechado, a não ser que tenha defaultOpen.

**Esperado:** Começar fechado e aceitar defaultOpen.

![Print do item 40](relatorio/img/40-1.webp)

### 41. A mensagem de erro manda rodar um comando de terminal

*Deployments, build com erro · Próprio*

**O que acontece:** O erro termina com "Run writedocs validate to list every problem in the project at once". Num projeto sem repositório, quem lê não tem terminal nem CLI. O dashboard já tem essa validação no Overview ("View validation").

**Esperado:** Trocar a dica por um link para a validação do dashboard. Deixar o comando só para projetos com repositório.

![Print do item 41](relatorio/img/41-1.webp)

### 42. O quadro de erro junta tudo numa linha só

*Deployments, build com erro · Próprio*

**O que acontece:** No log, o erro vem em linhas separadas: arquivo e posição, mensagem, dica. No quadro vermelho do topo, tudo vira uma frase corrida ("X Build failed purposeful-eror.mdx:5:1 Expected a closing tag... Run...").

**Esperado:** Arquivo e posição em destaque, depois a mensagem, depois a dica, cada um na sua linha.

![Print do item 42](relatorio/img/42-1.webp)

### 43. O erro só aparece depois de publicar

*Content, editor · Próprio*

**O que acontece:** A página com uma tag <Note> sem fechar foi salva sem nenhum aviso. O erro só apareceu no build. O dashboard já sabe validar o projeto, mas não usa isso ao salvar.

**Esperado:** Validar ao salvar e marcar a linha no editor, antes de o arquivo entrar no Publish.

### 44. O texto do selo de status do build desligado é difícil de entender

*Settings, General · Próprio*

**O que acontece:** Em Build status badge, com o selo desligado, a tela diz "The badge is off: its address shows "unknown".". Quem lê não sabe qual endereço, nem onde aparece "unknown".

**Esperado:** Algo como "The badge is off. If it's already in a README, it shows "unknown"." E mostrar o endereço do selo para copiar quando ele estiver ligado.

![Print do item 44](relatorio/img/44-1.webp)

### 45. Voltar versão: o horário do diálogo não bate com o da lista

*Deployments · Próprio*

**O que acontece:** O build da lista marcado "Nov 3, 10:03 AM" abre o diálogo "The site will serve the version published on Nov 3, 10:04 AM". Um horário é o da fila e o outro o da publicação, mas nada diz isso. Depois da troca, o status no topo continua "Live · 12 minutes ago", sem refletir a versão nova.

**Esperado:** O mesmo horário nos dois lugares. No topo, algo como "Live · restored version from 10:03 AM".

![Print do item 45](relatorio/img/45-1.webp)

### 46. O slug não é sugerido a partir do nome, e acento só gera erro

*Criação de projeto · Próprio*

**O que acontece:** Maiúsculas viram minúsculas sozinhas no slug, o que é bom. Mas espaço e acento não são convertidos: com "á", aparece o erro "Use only lowercase letters, numbers, and hyphens, with no hyphen at either end (up to 63).", e o texto de apoio mostra um endereço impossível ("á.writedocs.io"). O slug também não é preenchido a partir do nome do projeto ("TESTE COM MAIÚSCULAS").

**Esperado:** Converter também espaço em hífen e tirar o acento ("teste-com-maiusculas"), como já faz com maiúsculas, e sugerir o slug a partir do nome. O erro continua valendo para o que não dá para converter.

![Print do item 46](relatorio/img/46-1.webp)

### 47. Um problema vira duas mensagens de erro

*Site, JSON · Próprio*

**O que acontece:** Sem a chave "name", aparecem duas linhas para a mesma causa: "name" is required, but writedocs.json does not set it, e The site name can't be empty. O contador diz "2 unsaved changes" para uma única edição.

**Esperado:** Uma mensagem só: "Add the site name ("name"). It's required." E contar a edição como uma mudança.

![Print do item 47](relatorio/img/47-1.webp)

### 48. O corretor ortográfico do navegador marca o código

*Editor de código · Próprio*

**O que acontece:** No editor do writedocs.json, palavras como "openapi", "teste.yaml", "Documentação" e "purposeful-eror" ficam sublinhadas em vermelho pelo corretor do navegador. Em código, isso é ruído e parece erro.

**Esperado:** Desligar a correção ortográfica no editor de código (spellcheck="false").

![Print do item 48](relatorio/img/48-1.webp)

### 49. O exemplo "docs" no campo Subpath parece um valor preenchido

*Source and sync · Próprio*

**O que acontece:** O campo Subpath mostra "docs" em cinza. Parece que o conteúdo vai ser lido da pasta docs, mas é só um exemplo: depois de conectar, o resumo diz "Subpath: repository root", e o campo continua mostrando "docs". Quem tem o conteúdo na raiz, como neste teste, pode achar que precisa apagar o campo. É o mesmo problema do item 30.

**Esperado:** Deixar o campo vazio, com a dica embaixo ("Empty means the root. For example, docs"), ou mostrar "/ (repository root)" como valor.

![Print do item 49](relatorio/img/49-1.webp)

### 50. Abrir um arquivo que não é página mostra uma mensagem sobre imagens

*Content · Próprio*

**O que acontece:** Ao abrir o docs.json, vindo do repositório, a tela mostra o ícone de imagem e "This file isn't a page. Viewing and replacing images and other files is coming in a later version of the editor.". O arquivo é JSON, não imagem, e a mensagem não diz se o WriteDocs usa ou ignora esse arquivo.

**Esperado:** Uma mensagem de acordo com o tipo do arquivo. Para um docs.json do Mintlify, dizer o que acontece com ele: "WriteDocs reads its settings from writedocs.json. This docs.json from Mintlify isn't used." (confirmar o comportamento).

![Print do item 50](relatorio/img/50-1.webp)

### 51. A descrição do commit sai em português

*Commit no GitHub · Próprio*

**O que acontece:** A edição feita no dashboard virou o commit "Update quickstart", na branch main, com você como autora. Mas a descrição do commit sai em português, com plural improvisado: "WriteDocs: 1 arquivo(s) atualizado(s) via dashboard por jacqueline@writechoice.io". O título está em inglês, e o histórico do repositório é lido por toda a equipe do cliente.

**Esperado:** Descrição em inglês e com o número certo: "WriteDocs: 1 file updated from the dashboard by jacqueline@writechoice.io".

![Print do item 51](relatorio/img/51-1.webp)

### 52. A frase do conflito começa com letra minúscula

*Review and publish, conflito · Próprio*

**O que acontece:** No conflito, o texto começa com "a GitHub push published this file on Nov 4, 11:53 AM, after you started.". Parece que o começo da frase foi montado a partir de um trecho que ficaria no meio dela. Também não há opção de juntar as duas versões: só ficar com uma.

**Esperado:** "A GitHub push published this file on Nov 4, 11:53 AM, after you started." Avaliar uma terceira opção, "Edit to combine both", para quem quer manter partes das duas.

![Print do item 52](relatorio/img/52-1.webp)

---

## Severidade sugestão (5)

### 53. O primeiro build aparece como "Saved in editor"

*Deployments · Paridade*

**O que acontece:** A criação do projeto passa pelo editor, então está certo. Mas quem olha a lista ainda não editou nada.

**Esperado:** Rótulo próprio para o primeiro build, como "Project created".

![Print do item 53](relatorio/img/53-1.webp)

### 54. Nota da versão do gerador fora de lugar

*Source and sync · Próprio*

**O que acontece:** "Built with generator 0.13.5. Change the version in General" fica solta numa página sobre repositório.

**Esperado:** Deixar só em General e no Overview.

![Print do item 54](relatorio/img/54-1.webp)

### 55. Temas de código sem amostra de cor

*Site, Appearance, Code · Paridade*

**O que acontece:** Os temas aparecem com os nomes do Shiki (andromeeda, aurora-x...), sem dizer como são. Temas escuros no seletor do modo claro estão certos, porque valem só para o bloco de código.

**Esperado:** Uma amostra de cor ao lado de cada nome.

![Print do item 55](relatorio/img/55-1.webp)

### 56. A lista de temas cobre a prévia do código

*Site, Appearance, Code · Próprio*

**O que acontece:** A prévia muda assim que o tema é escolhido. Mas a lista aberta cobre o bloco de código, e não dá para comparar temas passando o mouse.

**Esperado:** Lista abrindo para baixo, ou prévia ao passar o mouse sobre cada tema.

![Print do item 56](relatorio/img/56-1.webp)

### 57. O destaque da aba não ajusta o contraste

*Site, Appearance, Top bar · Próprio*

**O que acontece:** O texto da barra vira branco ou preto sozinho, mas o "Open tab highlight" não: o roxo padrão sobre a barra vermelha quase some. O seletor de cor é a janela nativa do sistema.

**Esperado:** Checar o contraste do destaque também, ou avisar quando ficar baixo.

![Print do item 57](relatorio/img/57-1.webp)

---

## Comportamentos para registrar

Não são defeitos, mas valem explicação na documentação ou comparação com o Mintlify.

**Uma página pode ter três nomes diferentes.** A página de componentes tem title "Component test", sidebarTitle "Components" e arquivo components-list.mdx. A sidebar mostra "Components", o link "Next" da página anterior mostra "Component test" e a URL é /components-list/. O gerador respeita o frontmatter: a sidebar usa o sidebarTitle, a navegação anterior e próxima usa o title. Vale explicar isso na documentação do WriteDocs, para quem estranhar os nomes diferentes.

![Uma página pode ter três nomes diferentes](relatorio/img/nota-1.webp)

---

## Revisão do texto da interface

Está num arquivo separado: revisao-texto-writedocs.md.

---

## O que está bom

### Componentes do Mintlify funcionam sem alteração

Uma página escrita para o Mintlify, com 13 tipos de componente, publicou sem mudar nada: os seis callouts, Tabs, Steps, CardGroup, Columns, AccordionGroup, código com título e linha destacada, CodeGroup, ParamField, ResponseField, Tooltip, Icon, Badge, Frame, Mermaid, Update e tabela HTML com rowspan, colspan e negrito na célula. O frontmatter icon, sidebarTitle e title também funciona. A única diferença foi o item 40.

![Componentes do Mintlify funcionam sem alteração](relatorio/img/bom-1.webp)

### Review and publish

Lista cada arquivo com status, diff, descarte por arquivo e mensagem de commit sugerida.

![Review and publish](relatorio/img/bom-2.webp)

### Controle do que ainda não foi ao ar

Marcas N e M na lista de arquivos, "not published" no topo do arquivo, contador no botão Publish, barra "1 unsaved change" e ponto na seção alterada.

![Controle do que ainda não foi ao ar](relatorio/img/bom-3.webp)

### Criar página já coloca na navegação

Escolha do grupo, nome de arquivo gerado do título e caminho final mostrado antes de criar.

![Criar página já coloca na navegação](relatorio/img/bom-4.webp)

### Acompanhamento do publish

Status no topo explica que o site no ar não cai durante o build, com atalhos para o build e para os deploys.

![Acompanhamento do publish](relatorio/img/bom-5.webp)

### Página do build

Origem, quem disparou, versão do gerador, fila, início, fim, duração, tempo até o ar e log com busca. Rebuild bloqueado com explicação quando já há build na fila.

![Página do build](relatorio/img/bom-6.webp)

- **GitHub nos dois sentidos.** Depois de vincular a conta, a conexão lista repositórios e branches e confirma o primeiro sync. Um commit no GitHub chega sozinho ao dashboard e já dispara o build, como no Mintlify. Um publish no dashboard vira commit em segundos, com a pessoa como autora, título claro e só a linha alterada, e o arquivo mostra "Waiting for the commit to GitHub" enquanto isso. A autorização no GitHub pede só o e-mail, somente leitura.
- **Conflitos.** O editor avisa assim que chega um push do GitHub, com "See what changed". No Review and publish, o arquivo fica marcado "Needs you", com os dois diffs lado a lado e a escolha entre "Publish mine over it" e "Keep the published one". O Publish só libera depois da escolha, e o commit final não apaga o histórico. Nada se perde em silêncio.
- **Erros que ajudam.** Um erro de conteúdo falha em 13 s, mostra "Failed" e aponta arquivo, linha e coluna. Um erro no writedocs.json aponta a tela certa ("General > name") e bloqueia o Save. A criação de projeto valida tudo de uma vez, com um link para cada campo, e o slug já usado é avisado na hora.
- **Ações destrutivas com cuidado.** Descartar pede confirmação na própria linha. Voltar versão explica o que muda, quanto tempo leva e como desfazer, sem gerar build novo. Excluir projeto pede para digitar o nome e avisa que, sem repositório, não há outra cópia. Transferir a propriedade explica que quem transfere continua como admin.
- **Configurações bem explicadas.** Site password diz o que fica privado (páginas, busca, llms.txt, sitemap, /mcp) e por quanto tempo a pessoa fica logada. Members mostra numa tabela o que cada papel pode fazer. A versão do gerador pode seguir o stable ou ficar fixa. Trocar o endereço explica o redirect de 90 dias. Site > General explica que o nome do site não é o nome do projeto.
- **Aparência.** A prévia muda na hora, em claro e escuro, antes de salvar, com tema de código separado para cada modo. A cor da barra do topo ajusta o contraste do texto sozinha.
- **Dashboard em três idiomas.** Português, English e Español, ou seguir o navegador. O Mintlify não oferece o dashboard em português.
- **Site gerado.** Copy page, busca no Ctrl K, navegação anterior e próxima, servidor MCP em /mcp e a validação do writedocs.json no Overview.
- **Texto da interface.** Claro e direto no geral, principalmente na criação de projeto, em Source and sync e nos status de publicação. O aviso "Saved, not published yet" explica o rascunho na hora certa.

## Perguntas para você

1. O dashboard sempre faz commit direto na main, ou dá para escolher uma branch ou abrir um pull request, como no editor do Mintlify?
2. O aviso "requires write access... confirmed in the last 7 days", com o botão "Confirm GitHub access", é obrigatório? A conexão funcionou sem clicar nele.
3. Analytics e o assistente de IA ("Ask AI", citado em Site password) já existem ou estão em construção?
4. Escolha de tema ou layout do site e API reference com OpenAPI: existem, estão em construção, ou entram por outra chave do writedocs.json? Nenhum dos dois aparece em Appearance nem no JSON, mas Appearance cita um "API playground". A chave "openapi" passou sem erro, porque a validação ignora chaves que não conhece (item 14).
5. O conteúdo inicial em português (item 05) vem do idioma do navegador, da página da conta ou de outro lugar?
6. Quando renomear arquivos for possível (item 12), o endereço antigo vai redirecionar para o novo?
