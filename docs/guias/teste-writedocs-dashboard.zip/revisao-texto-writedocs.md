# Revisão do texto da interface: WriteDocs dashboard

Complemento do relatório de teste (teste-writedocs-dashboard.md). Os números de item citados aqui são os do relatório.

Esta seção revisa só as palavras do dashboard. Cada achado traz o texto atual, o texto proposto em inglês pronto para colar, o motivo e a severidade; quando ele é o lado textual de um item do relatório, o número do item aparece em "item" e o conserto de comportamento continua lá. Propostas que terminam em "(confirm)" dependem de um comportamento que as telas não mostram: confirme e tire a marca antes de colar.

## O que corrigir primeiro

1. Parar de dizer que terminou antes de terminar: "Published" logo depois do clique, "Done" na troca de versão e "Building" depois de três tentativas falhas (T25, T34, T35).
2. Separar salvar de publicar: "saved" aparece depois do Publish e numa promessa de que salvar leva ao site (T10, T12, T26, T31).
3. Dar à falha o mesmo peso do sucesso e dizer sempre que o site no ar não mudou (T28, T29, T37).
4. Não prometer uma exclusão que não acontece (T58).
5. Tirar o português da interface em inglês: página inicial, log, commit e exemplo de domínio (T04, T36, T42, T51).

## Uma palavra por conceito

- **save** para Guardar uma mudança no WriteDocs sem levar ao site. Hoje aparece como: saved, stays saved without publishing, Saved in WriteDocs (depois do Publish), Saved in editor (origem do build), You saved a change (depois do Publish), goes to the site when you save.
- **publish** para Levar as mudanças salvas ao site. Hoje aparece como: Publish, Publishing, takes it all to the site, Trigger to live, Published (antes de terminar).
- **build** para Cada execução que gera o site. Hoje aparece como: build, deployment, Rebuild, attempt.
- **Builds** para A lista de builds. Hoje aparece como: Deployments, All deployments, Deployment history, All builds.
- **live site** para O site publicado que as pessoas abrem. Hoje aparece como: Live, the site, the live site, the site is published.
- **restore** para Pôr no ar de novo um build anterior. Hoje aparece como: Go back to this version, Switch the site to this version, putting the site back on a previous version, restored.
- **configuration** para O writedocs.json e as telas que o editam. Hoje aparece como: Site, JSON, writedocs.json, Configuration, site configuration, configuration.
- **Settings** para Configurações do projeto. Hoje aparece como: Settings, Project settings, General.
- **navigation** para A estrutura de menus do site. Hoje aparece como: navigation, Navigation, menu.
- **connect a repository** para Ligar o projeto a um repositório. Hoje aparece como: Connect to GitHub, connect a repository, Connect a repository.
- **connect GitHub** para Ligar a conta WriteDocs à conta GitHub. Hoje aparece como: Connect GitHub, linked to a GitHub account, Connect.
- **conflict** para Mesmo arquivo mudado no WriteDocs e no GitHub. Hoje aparece como: Conflicts, Needs you, 1 file needs you, one of the two versions stays.

## Status fixos

- Depois do Publish, antes de o build começar (hoje "Publishing shortly" e depois "Queued"): pill **Queued**, menu "The build starts in a few seconds. Your live site doesn't change until it finishes."
- Build rodando (hoje "Publishing" no topo e "Building" em Deployments): pill **Building**, menu "Building the site with your changes. Your live site doesn't change until the build finishes."
- Esperando a versão nova do gerador, com novas tentativas automáticas (hoje "Building", com abas "failed"): pill **Waiting for update**, menu "Waiting for generator 0.14.0. Trying again in 2 minutes. Your live site didn't change."
- Build terminou e o site está no ar: pill **Live**, menu "Published 2 minutes ago. The site shows your latest published changes."
- Build falhou (hoje "Failed"): pill **Build failed**, menu "The last build failed 9 minutes ago. Your live site didn't change. See the build to fix the error."
- Voltando para um build anterior (hoje a pílula fica em "Live"): pill **Restoring**, menu "Restoring the version from Nov 3, 10:04 AM. This takes up to a minute."

## Achados de texto

### T01. Create project (Baixa)

- **Atual:** Becomes the site address: your-project.writedocs.io
- **Proposta:** Site address: your-project-dev.writedocs.io (confirm)
- **Por quê:** O endereço real ganha "-dev" e a linha mostra outro. Com um slug que não vale (como "á"), a linha também mostra um endereço que não existe; melhor esconder até o slug valer. Ver item 19 do relatório.

![T01](relatorio/img/19-1.webp)

![T01](relatorio/img/19-2.webp)

### T02. Create project (Baixa)

- **Atual:** Available
- **Proposta:** Slug available
- **Por quê:** Lida sozinha por leitor de tela, a palavra não diz o que está disponível.

![T02](relatorio/img/t02-1.webp)

### T03. Create project (Baixa)

- **Atual:** Use only lowercase letters, numbers, and hyphens, with no hyphen at either end (up to 63).
- **Proposta:** Use up to 63 lowercase letters, numbers, and hyphens. Don't start or end with a hyphen.
- **Por quê:** O "(up to 63)" no fim não diz 63 de quê. Ver item 46 do relatório.

![T03](relatorio/img/46-1.webp)

### T04. Site gerado, página inicial (Média)

- **Atual:** Esta é a primeira página da documentação de Let's break this. Ela foi criada junto com o projeto, para o site já nascer publicado. Para trazer o seu conteúdo, conecte um repositório do GitHub nas configurações do projeto.
- **Proposta:** This is the first page of the Let's break this documentation. WriteDocs created it with the project, so the site is live from the start. To add your content, edit this page or create new pages in Content.
- **Por quê:** Sai em português num dashboard em inglês e manda conectar o GitHub num projeto criado sem repositório (item 20). O texto proposto serve aos dois tipos de projeto. Ver item 05 do relatório.

![T04](relatorio/img/05-1.webp)

### T05. Site gerado, grupo de navegação (visto em New page) (Baixa)

- **Atual:** Where: Documentação
- **Proposta:** Where: Documentation
- **Por quê:** O grupo de navegação criado junto com o projeto vem em português. Ver item 05 do relatório.

![T05](relatorio/img/05-1.webp)

### T06. Overview (Baixa)

- **Atual:** Deployment history: All builds, what's live, and putting the site back on a previous version
- **Proposta:** Builds: every build, which one is live, and how to restore an earlier version
- **Por quê:** Mistura "deployment" e "build" na mesma linha para a mesma coisa, e "putting the site back" é um terceiro nome para restaurar. Ver o vocabulário.

![T06](relatorio/img/t06-1.webp)

### T07. Content (Baixa)

- **Atual:** Expand on hover
- **Proposta:** Expand sidebar on hover (confirm)
- **Por quê:** Não diz o que expande. Ver item 29 do relatório.

![T07](relatorio/img/29-1.webp)

### T08. Content, Navigation (Baixa)

- **Atual:** 1 page · 0 not found
- **Proposta:** 1 page · 0 missing files (confirm)
- **Por quê:** "0 not found" não diz o que não foi encontrado.

![T08](relatorio/img/t08-1.webp)

### T09. Content, Navigation (Média)

- **Atual:** writedocs.json  open in Site
- **Proposta:** writedocs.json · Open in Configuration
- **Por quê:** "Site" é o nome da seção e também o site publicado; "open in Site" pode ser lido como abrir o site no ar. Ver T16.

![T09](relatorio/img/t09-1.webp)

### T10. Content, editor (Média)

- **Atual:** Saved in WriteDocs on Nov 3, 09:49 AM (file header right after Publish)
- **Proposta:** While the build runs: Publishing. After it finishes: Published Nov 3, 09:49 AM (confirm)
- **Por quê:** Depois do Publish o cabeçalho usa "Saved", a palavra do rascunho, e não diz se a página foi publicada.

![T10](relatorio/img/t10-1.webp)

### T11. Content, Navigation, Add tab (Baixa)

- **Atual:** Add: Tab
- **Proposta:** Add tab
- **Por quê:** Os dois pontos partem o título; como ação, ele lê direto.

![T11](relatorio/img/t11-1.webp)

### T12. Content, Navigation, Add tab (Média)

- **Atual:** The change shows in the navigation right away, and goes to the site when you save.
- **Proposta:** The change shows here right away. It goes to the site when you publish.
- **Por quê:** Salvar não leva ao site; só o Publish leva. Ver item 11 do relatório.

![T12](relatorio/img/11-1.webp)

### T13. Content, Navigation, menu do item (Baixa)

- **Atual:** Remove
- **Proposta:** Remove from navigation (confirm)
- **Por quê:** Sem objeto, "Remove" pode ser lido como apagar o arquivo. Confirmar que o arquivo fica no projeto.

![T13](relatorio/img/t13-1.webp)

### T14. New page (Baixa)

- **Atual:** It starts with the title and opens in the editor. It stays saved without publishing until you publish.
- **Proposta:** The page opens in the editor with this title. It goes to the site only when you publish.
- **Por quê:** Repete "publish" e "saved" sem acrescentar nada. Ver item 34 do relatório.

![T14](relatorio/img/34-1.webp)

### T15. New page (Baixa)

- **Atual:** The menu is saved along with the page.
- **Proposta:** The navigation change is saved with the page.
- **Por quê:** O resto do dashboard chama isso de navigation, e "menu" já é o nome do menu de cada item da navegação.

![T15](relatorio/img/t15-1.webp)

### T16. Site (configuração do site) (Média)

- **Atual:** Site (section name: Site > General, Site > Appearance, Site > JSON)
- **Proposta:** Configuration (Configuration > General, Configuration > Appearance, Configuration > JSON)
- **Por quê:** "Site" nomeia a seção e também o site publicado. O produto já chama esse conteúdo de configuration no Overview ("Configuration (writedocs.json)"), no rótulo do arquivo na lista e na mensagem de commit sugerida.

![T16](relatorio/img/t16-1.webp)

### T17. Site, General (Baixa)

- **Atual:** It's not the project name here in the dashboard (Let's break this). Change the project name in General
- **Proposta:** This isn't the project name shown in the dashboard (Let's break this). To change it, go to Settings > General.
- **Por quê:** A pessoa já está numa página chamada General, então "in General" aponta para o lugar errado. Ver item 23 do relatório.

![T17](relatorio/img/23-1.webp)

### T18. Site, Appearance (Baixa)

- **Atual:** Empty uses the default color, shown in the field.
- **Proposta:** Leave empty to use the default color (#6366f1).
- **Por quê:** O campo mostra o padrão como se fosse um valor definido. Com o padrão na dica, o campo pode ficar vazio. Ver item 30 do relatório.

![T18](relatorio/img/30-1.webp)

### T19. Site, Appearance (Baixa)

- **Atual:** Empty uses the main color. Needs the bar background.
- **Proposta:** Leave empty to use the main color. Works only when the top bar has a color. (confirm)
- **Por quê:** "Needs the bar background" não diz o que fazer.

![T19](relatorio/img/t19-1.webp)

### T20. Site, JSON (Baixa)

- **Atual:** 2 unsaved changes · fix the highlighted fields
- **Proposta:** 2 unsaved changes · Fix the highlighted errors to save (confirm)
- **Por quê:** Num editor de JSON não há campos, e a frase não diz se o Save fica bloqueado até corrigir.

![T20](relatorio/img/t20-1.webp)

### T21. Site, JSON (Baixa)

- **Atual:** General › name: "name" is required, but writedocs.json does not set it. / General › name: The site name can't be empty.
- **Proposta:** General › name: Add the site name. writedocs.json has no "name" key.
- **Por quê:** Um problema, duas mensagens. Ver item 47 do relatório.

![T21](relatorio/img/47-1.webp)

### T22. Site, JSON (Média)

- **Atual:** No errors. (with "nmae" or "openapi" in the file)
- **Proposta:** Unknown key "nmae". Did you mean "name"? (confirm)
- **Por quê:** Hoje diz "No errors." com uma chave que o WriteDocs não conhece. Ver item 14 do relatório.

![T22](relatorio/img/14-1.webp)

![T22](relatorio/img/14-2.webp)

### T23. Review and publish (Baixa)

- **Atual:** It goes into the project history (and to GitHub, with a repository). It comes with a suggestion; left empty, the usual message is used.
- **Proposta:** Goes into the project history, and to GitHub when a repository is connected. If you leave it empty, WriteDocs uses: <default message>
- **Por quê:** Não mostra qual é a "usual message". Ver item 35 do relatório.

![T23](relatorio/img/35-1.webp)

### T24. Review and publish (Média)

- **Atual:** Discard all saved changes? / Cancel / Discard all
- **Proposta:** Discard all unpublished changes? / Your saved changes in these files are deleted. The live site doesn't change. You can't undo this. (confirm) / Cancel / Discard all
- **Por quê:** A confirmação não diz o que se perde nem se dá para desfazer, e é a única ação dessa tela que apaga trabalho.

![T24](relatorio/img/t24-1.webp)

### T25. Status de publicação (topo) (Alta)

- **Atual:** Published. The site updates in a moment. / With a repository: Published. The change goes to GitHub in a few seconds, and the site updates right after.
- **Proposta:** Publishing started. The site updates when the build finishes. / With a repository: Publishing started. Your changes go to GitHub first, then the site updates.
- **Por quê:** Diz "Published" antes de o build começar. Se o build falhar, a pessoa já saiu achando que está no ar. Ver item 04 do relatório.

![T25](relatorio/img/04-1.webp)

![T25](relatorio/img/04-2.webp)

### T26. Status de publicação (topo) (Média)

- **Atual:** Pill: Publishing shortly / Menu: You saved a change. The build starts in a few seconds.
- **Proposta:** Pill: Queued / Menu: The build starts in a few seconds. Your live site doesn't change until it finishes.
- **Por quê:** A pessoa acabou de publicar, não de salvar; e "Publishing shortly" e "Queued" são dois nomes para a mesma espera. Ver a tabela de status. Ver item 10 do relatório.

![T26](relatorio/img/10-1.webp)

### T27. Status de publicação (topo) (Média)

- **Atual:** Pill: Publishing · now (the same build shows "Building" in Deployments)
- **Proposta:** Pill: Building · now / Menu: Building the site with your changes. Your live site doesn't change until the build finishes.
- **Por quê:** O mesmo build se chama "Publishing" no topo e "Building" em Deployments.

![T27](relatorio/img/t27-1.webp)

### T28. Status de publicação (topo) (Média)

- **Atual:** Pill: Failed · 9 minutes ago / Menu: The last build failed 9 minutes ago. The live site stays the previous one.
- **Proposta:** Pill: Build failed · 9 minutes ago / Menu: The last build failed 9 minutes ago. Your live site didn't change. See the build to fix the error.
- **Por quê:** "Failed" sozinho no topo pode ser lido como o site fora do ar. O menu explica, mas só quem abre vê, e não diz o próximo passo.

![T28](relatorio/img/t28-1.webp)

### T29. Status de publicação (topo) (Média)

- **Atual:** (No notice seen when a build failed. Success shows "The site was published." with Open the site.)
- **Proposta:** Build failed. Your live site didn't change. / See the build (confirm)
- **Por quê:** Pelas telas, o sucesso ganha aviso e a falha só muda a pílula. A falha precisa de pelo menos o mesmo destaque, num lugar que não some.

### T30. Deployments (Média)

- **Atual:** Deployments / All deployments
- **Proposta:** Builds / All builds
- **Por quê:** Cada linha é um build (Rebuild, Latest build log, Build failed); só o nome da página e o link do menu chamam de deployment.

![T30](relatorio/img/t30-1.webp)

### T31. Deployments (Média)

- **Atual:** Saved in editor
- **Proposta:** Dashboard (publishes from the editor) / Project created (the first build) (confirm)
- **Por quê:** "Saved" é a palavra do rascunho, mas o build vem de um Publish; e o primeiro build nem passou pelo editor. Ver item 53 do relatório.

![T31](relatorio/img/53-1.webp)

### T32. Deployments (Média)

- **Atual:** Button: Go back to this version / Dialog title: Switch the site to this version?
- **Proposta:** Button: Restore this version / Dialog title: Restore this version? / Confirm button: Restore version
- **Por quê:** Três verbos para a mesma ação (go back, switch, e "restored" no corpo do diálogo). O botão de confirmação deve repetir o título.

![T32](relatorio/img/t32-1.webp)

### T33. Deployments (Baixa)

- **Atual:** Nov 3, 10:03 AM (row) / published on Nov 3, 10:04 AM (dialog)
- **Proposta:** Row: Published Nov 3, 10:04 AM / Dialog: published on Nov 3, 10:04 AM (confirm which time each one shows)
- **Por quê:** Se forem dois momentos diferentes, cada um precisa de rótulo; se for o mesmo, o mesmo valor. Ver item 45 do relatório.

![T33](relatorio/img/45-1.webp)

### T34. Deployments (Média)

- **Atual:** Done: the site is switching... (the pill stays "Live · 12 minutes ago")
- **Proposta:** Banner: Restoring the version from Nov 3, 10:04 AM. This takes up to a minute. / Pill: Restoring (confirm)
- **Por quê:** Diz "Done" enquanto ainda troca, e a pílula não mostra que algo está acontecendo.

![T34](relatorio/img/t34-1.webp)

### T35. Página do build (Alta)

- **Atual:** Badge: Building / Tabs: Attempt 1 (failed) / Attempt 2 (failed) / Attempt 3 (failed) / Live log
- **Proposta:** Badge: Waiting for update / Line above the log: Waiting for generator 0.14.0. Trying again in 2 minutes (attempt 3 of 18). Your live site didn't change. / Tabs: Attempt 1 (waiting), Attempt 2 (waiting)
- **Por quê:** O status diz que está construindo, e as abas dizem que falhou. Nenhum dos dois é verdade: o build está esperando a versão nova do gerador, e o conteúdo não tem erro. "Failed" fica só para erro real de build. Ver item 02 do relatório.

![T35](relatorio/img/02-1.webp)

### T36. Página do build (Média)

- **Atual:** A versão 0.14.0 do gerador ainda não chegou à imagem que constrói o site. [...] O build tenta de novo em 2 minutos (espera 3 de 18). Se a versão não chegar em 36 minutos, o build falha. / == classificação: transitória - generator_version_mismatch ==
- **Proposta:** Generator 0.14.0 isn't ready to build sites yet, because the platform was just updated. Nothing is wrong with your content. Trying again in 2 minutes (attempt 3 of 18). If it isn't ready in 36 minutes, the build fails.
- **Por quê:** Português na interface em inglês. "Imagem" e a linha de classificação são da infraestrutura; a linha sai. Ver item 08 do relatório.

![T36](relatorio/img/08-1.webp)

### T37. Página do build (Média)

- **Atual:** Stopped at step: build / X Build failed purposeful-eror.mdx:5:1 Expected a closing tag for `<Note>` (5:1-5:7) before the end of `paragraph` Run "writedocs validate" to list every problem in the project at once.
- **Proposta:** Build failed. Your live site didn't change. / purposeful-eror.mdx, line 5: the <Note> tag isn't closed. Add </Note>, then publish again.
- **Por quê:** Manda rodar um comando de terminal para quem pode estar só no navegador, e não diz o que houve com o site no ar. "Stopped at step: build" repete o título. Ver item 41 do relatório.

![T37](relatorio/img/41-1.webp)

### T38. Página do build (Baixa)

- **Atual:** Trigger to live
- **Proposta:** Time to go live (confirm)
- **Por quê:** Não diz se é um horário ou uma duração. Pela posição, depois de Duration, parece o tempo total do clique até o site no ar.

![T38](relatorio/img/t38-1.webp)

### T39. Página do build (Baixa)

- **Atual:** Commit: (only a dash, no value)
- **Proposta:** Commit: No repository (confirm)
- **Por quê:** O traço não diz se falta o dado ou se o campo não se aplica. Ver item 37 do relatório.

![T39](relatorio/img/37-1.webp)

### T40. Settings, General (Média)

- **Atual:** Follow stable (0.13.5)
- **Proposta:** Latest stable (now 0.13.5). Updates by itself when a new stable version comes out, which starts a new build. (confirm)
- **Por quê:** Não avisa que a versão troca sozinha. Ver item 09 do relatório.

![T40](relatorio/img/09-1.webp)

### T41. Settings, General (Baixa)

- **Atual:** The badge is off: its address shows "unknown".
- **Proposta:** The badge is off. Until you turn it on, the badge image shows "unknown". (confirm)
- **Por quê:** "Its address" faz pensar no link, quando quem mostra "unknown" é a imagem do selo. Ver item 44 do relatório.

![T41](relatorio/img/44-1.webp)

### T42. Settings, Domains (Baixa)

- **Atual:** docs.empresa.com / empresa.com
- **Proposta:** docs.example.com / example.com
- **Por quê:** Exemplo em português na interface em inglês. Ver item 32 do relatório.

![T42](relatorio/img/32-1.webp)

### T43. Source and sync (Sugestão)

- **Atual:** Built with generator 0.13.5. Change the version in General
- **Proposta:** Built with generator 0.13.5. To change the version, go to Settings > General.
- **Por quê:** Há dois General no dashboard; o link precisa dizer qual. Ver item 54 do relatório.

![T43](relatorio/img/54-1.webp)

### T44. Source and sync (Média)

- **Atual:** Connect to GitHub (section title, project)
- **Proposta:** Connect a repository
- **Por quê:** "Connect to GitHub" (o repositório do projeto) e "Connect GitHub" (a conta, em sign-in methods) são ações diferentes com quase o mesmo nome, e o erro manda fazer uma de dentro da outra. O produto já diz "connect a repository" em vários lugares.

![T44](relatorio/img/t44-1.webp)

### T45. Source and sync (Média)

- **Atual:** To install, your WriteDocs account needs to be linked to a GitHub account: that's how we confirm that the person authorizing on GitHub is you. Connect GitHub in sign-in methods
- **Proposta:** (Shown before the Install the GitHub App button) Before you install, connect GitHub in your account's sign-in methods. WriteDocs uses it to confirm that you're the one installing the app.
- **Por quê:** Hoje o pré-requisito só aparece depois do clique, como erro. Ver item 17 do relatório.

![T45](relatorio/img/17-1.webp)

![T45](relatorio/img/17-2.webp)

### T46. Source and sync (Baixa)

- **Atual:** The folder in the repository where the content lives. Empty means the root. (field shows "docs" in grey)
- **Proposta:** The folder in the repository where the content lives, for example docs. Leave empty to use the root.
- **Por quê:** O "docs" cinza parece valor preenchido; o exemplo vai para a dica. Ver item 49 do relatório.

![T46](relatorio/img/49-1.webp)

### T47. Source and sync (Baixa)

- **Atual:** Syncing / Not synced yet.
- **Proposta:** Syncing / First sync in progress.
- **Por quê:** Lidas juntas, as duas linhas parecem se contradizer.

![T47](relatorio/img/t47-1.webp)

### T48. GitHub, repositório no formato do Mintlify (Baixa)

- **Atual:** This file isn't a page. Viewing and replacing images and other files is coming in a later version of the editor. (docs.json, with an image icon)
- **Proposta:** This file can't be opened in the editor yet. The editor opens pages and writedocs.json. (confirm)
- **Por quê:** Fala de imagens para um arquivo JSON. Ver item 50 do relatório.

![T48](relatorio/img/50-1.webp)

### T49. GitHub, repositório no formato do Mintlify (Média)

- **Atual:** This project has no writedocs.json yet. The site's navigation lives in writedocs.json. Connect a repository that has one, or create the project from the starter.
- **Proposta:** This project has no writedocs.json yet, so there's no navigation to show. Add writedocs.json to the repository, then sync. (confirm)
- **Por quê:** O repositório já está conectado, e "create the project from the starter" manda recomeçar do zero. Ver item 18 do relatório.

![T49](relatorio/img/18-1.webp)

### T50. GitHub, repositório no formato do Mintlify (Média)

- **Atual:** (Publish is disabled, with no text)
- **Proposta:** Tooltip on Publish: Publishing needs a writedocs.json in the repository. (confirm)
- **Por quê:** Um botão desligado sem motivo deixa a pessoa sem saber o que fazer. Ver item 03 do relatório.

![T50](relatorio/img/03-1.webp)

![T50](relatorio/img/03-2.webp)

### T51. GitHub, publicar com repositório (Baixa)

- **Atual:** WriteDocs: 1 arquivo(s) atualizado(s) via dashboard por <email>
- **Proposta:** WriteDocs: updated 1 file from the dashboard (<email>) / plural: updated 2 files
- **Por quê:** Português no histórico do repositório de um projeto em inglês, e "(s)" no lugar do plural. Ver item 51 do relatório.

![T51](relatorio/img/51-1.webp)

### T52. GitHub, publicar com repositório (Baixa)

- **Atual:** From GitHub / In GitHub (file header)
- **Proposta:** Last change from GitHub / Committed to GitHub (confirm)
- **Por quê:** Dois rótulos quase iguais para estados diferentes; pela tela não dá para saber a diferença.

![T52](relatorio/img/t52-1.webp)

### T53. Conflitos (Baixa)

- **Atual:** No conflicts. The content here and on GitHub match. (project without a repository)
- **Proposta:** Conflicts show up here only when a repository is connected.
- **Por quê:** Fala em GitHub num projeto sem repositório. Ver item 24 do relatório.

![T53](relatorio/img/24-1.webp)

![T53](relatorio/img/24-2.webp)

### T54. Conflitos (Baixa)

- **Atual:** Badge: Needs you / Footer: 1 file needs you
- **Proposta:** Badge: Conflict / Footer: 1 file has a conflict
- **Por quê:** Status diz o estado; "Needs you", lido sozinho, não diz o que houve.

![T54](relatorio/img/t54-1.webp)

![T54](relatorio/img/t54-2.webp)

### T55. Conflitos (Média)

- **Atual:** a GitHub push published this file on Nov 4, 11:53 AM, after you started. For now, one of the two versions stays.
- **Proposta:** A GitHub push changed this file on Nov 4, 11:53 AM, after you started editing. Choose which version to publish. The other one is discarded. (confirm)
- **Por quê:** Além da minúscula, "For now, one of the two versions stays" dá a entender que depois as versões se juntam. Ver item 52 do relatório.

![T55](relatorio/img/52-1.webp)

### T56. Conflitos (Baixa)

- **Atual:** Publish mine over it / Keep the published one
- **Proposta:** Publish my version / Keep the GitHub version
- **Por quê:** "Mine" e "the published one" pedem releitura; os botões devem repetir a palavra "version" do texto.

![T56](relatorio/img/t56-1.webp)

### T57. Account (Baixa)

- **Atual:** Download my data (next to "Delete your account")
- **Proposta:** Download your data
- **Por quê:** Mistura "my" e "your" na mesma seção.

![T57](relatorio/img/t57-1.webp)

### T58. Danger zone (Alta)

- **Atual:** Delete forever, then a toast that disappears: This doesn't work with real data yet: the platform doesn't have this part yet.
- **Proposta:** In the section, with the button disabled: Deleting projects isn't available yet. / If the dialog stays: Project not deleted. Deleting projects isn't available yet.
- **Por quê:** O diálogo promete exclusão permanente e o aviso de que nada aconteceu some sozinho; a pessoa pode sair achando que excluiu. Ver item 16 do relatório.

![T58](relatorio/img/16-1.webp)

![T58](relatorio/img/16-2.webp)

## O que manter

- As frases que dizem o que acontece com o site no ar ("The live site stays the previous one until it finishes."): é a ideia certa. A proposta só encurta e repete em todo status de espera e de falha.
- O aviso depois de salvar ("Saved, not published yet. You can change other files and publish everything at once.") e a barra "writedocs.json has saved changes that aren't published yet." com Review and publish.
- O toast "Repository connected. The first sync has started.": diz que começou, não que terminou. É o modelo para o toast do Publish.
- O diálogo de exclusão: título com o nome do projeto, consequência clara, aviso de que sem repositório não há outra cópia, e digitar o nome para confirmar.
- A troca de endereço: diz que o antigo redireciona por 90 dias e que os links do dashboard não mudam.
- O resumo de erros da criação de projeto, com link para cada campo, e o estado vazio do log ao vivo ("The log will appear here as soon as it starts.").
